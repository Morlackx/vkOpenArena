#ifndef R_STRETCHRAW_H_
#define R_STRETCHRAW_H_


void RE_StretchRaw (int x, int y, int w, int h, int cols, int rows, const unsigned char *data, int client, qboolean dirty);


#endif
