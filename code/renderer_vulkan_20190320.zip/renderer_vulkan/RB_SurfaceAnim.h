#ifndef RB_SURFACEANIM_H
#define RB_SURFACEANIM_H
#include "tr_model.h"
void RB_SurfaceAnim( md4Surface_t *surfType );
void RB_MDRSurfaceAnim( mdrSurface_t *surface );
#endif
