#ifndef TR_FOG_H_
#define TR_FOG_H_


void R_InitFogTable( void );
float R_FogFactor( float s, float t );


#endif
