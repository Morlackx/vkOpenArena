#ifndef R_MODELBOUNDS_H_
#define R_MODELBOUNDS_H_


void R_ModelBounds( qhandle_t handle, vec3_t mins, vec3_t maxs );


#endif
