#ifndef R_LERPTAG_H_
#define R_LERPTAG_H_


int	R_LerpTag( orientation_t *tag, qhandle_t handle, int startFrame, int endFrame, 
					 float frac, const char *tagName );


#endif
