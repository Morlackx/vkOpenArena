#ifndef TR_FLARE_H_
#define TR_FLARE_H_


void RB_SurfaceFlare(srfFlare_t *surf);


#endif
