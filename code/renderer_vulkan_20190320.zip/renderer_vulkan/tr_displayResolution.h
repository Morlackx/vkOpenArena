#ifndef TR_DISPLAY_RESOLUTION_LIST_H_
#define TR_DISPLAY_RESOLUTION_LIST_H_


void R_DisplayResolutionList_f(void);
void R_GetModeInfo(unsigned int *width, unsigned int *height, float *windowAspect, int mode );
void R_InitDisplayResolution( void );


#endif
