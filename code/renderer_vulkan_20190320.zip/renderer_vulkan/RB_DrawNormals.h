#ifndef RB_SHOW_NORMALS_H_
#define RB_SHOW_NORMALS_H_

void RB_DrawNormals (shaderCommands_t *input);

#endif
