#ifndef R_DEBUG_H_
#define R_DEBUG_H_

void R_DebugGraphics(void);
void RB_ShowImages(void);

void DrawTris (shaderCommands_t *input);
void DrawNormals (shaderCommands_t *input);


#endif
