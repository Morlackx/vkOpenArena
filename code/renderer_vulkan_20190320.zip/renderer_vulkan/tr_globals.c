#include "tr_globals.h"

trGlobals_t		tr;

