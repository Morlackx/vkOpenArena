#ifndef VK_DEPTH_IMAGE_H_
#define VK_DEPTH_IMAGE_H_

void vk_createDepthAttachment(void);
void vk_destroyDepthAttachment(void);


#endif
