#ifndef RB_DRAWTRIS_H_
#define RB_DRAWTRIS_H_

#include "tr_local.h"
void RB_DrawTris (shaderCommands_t *input);


#endif
