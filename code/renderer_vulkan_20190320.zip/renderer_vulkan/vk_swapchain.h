#ifndef VK_SWAPCHAIN_H_
#define VK_SWAPCHAIN_H_


void vk_recreateSwapChain(void);


#endif
